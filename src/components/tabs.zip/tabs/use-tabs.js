import React, { isValidElement, useMemo, useState, useRef } from 'react'
import Taro from '@tarojs/taro'
import { useMemoizedFn, useUpdateEffect, useMount } from 'ahooks'
import usePropsValue from '../../hooks/use-props-value'
import useTouch from '../../utils/use-touch'
import traverseReactNode from '../../utils/traverse-react-node'
import { isDef, isFunction } from '../../utils/validator'
import { TYPE_LINE } from './tabs'
import Tab from './tab'

const useTabs = props => {
	const {
		type,
		lazyRender,
		ellipsis,
		animated,
		swipeThreshold,
		swipeable,
		sticky,
		children,
		onBeforeChange
	} = props

	const [value, setValue] = usePropsValue({
    value: props.value,
    defaultValue: props.defaultValue,
    onChange: v => {
      props.onChange?.(v)
    }
  })

	const tabs = useMemo(() => {
		const result = []

		traverseReactNode(children, (child, index) => {
			if (!isValidElement(child)) return

			if (child.type !== Tab) {
				return
			}

			result.push({
				index,
				...child.props
			})	
		})

		return result
	}, [children])

	const ref = useRef()
	const touch = useTouch()

	const [scrollable, setScrollable] = useState(getScrollable)
	const [swiping, setSwiping] = useState(false)
	const [stickyContainer, setStickContainer] = useState(null)

	const [currentIndex, setCurrentIndex] = useState(() => {
		if (isDef(value)) {
			return getCurrentIndexByValue(value)
		}

		return 0
	})

	const isLineType = type === TYPE_LINE

	const onClickTab = useMemoizedFn((event) => {
		const { value: val } = event.currentTarget.dataset

		const index = getCurrentIndexByValue(val)

		if (index === currentIndex) {
			return
		}

		if (isFunction(onBeforeChange)) {
			const tab = getTabByIndex(index)

			onBeforeChange({
				index,
				value: val,
				title: tab.title
			}).then(() => {
				setCurrentIndex(index)
				setValue(val)
			})
		}else {
			setCurrentIndex(index)
			setValue(val)
		}
	})
	
	const onTouchStart = useMemoizedFn((event) => {
		if (!swipeable) return	

		setSwiping(true)

		touch.start(event)
	})

	const onTouchMove = useMemoizedFn((event) => {
		if (!swipeable || !swiping) return

		touch.move(event)
	})

	const onTouchEnd = useMemoizedFn((event) => {
		if (!swipeable || !swiping) return

		const { deltaX, offsetX } = touch
		const minSwipeDistance = 50

		if (touch.isHorizontal() && offsetX >= minSwipeDistance) {
			const index = getCurrentIndexByDeltaX(deltaX)

			if (index !== -1) {
				setCurrentIndex(index)
			}
		}

		setSwiping(false)
	}) 


	function getScrollable() {
		return children.length > swipeThreshold || !ellipsis
	}	

	function getCurrentIndexByValue(val) {
		const findedIndex = tabs.findIndex((item, index) => {
			if (isDef(item.value) && item.value === val)  {
				return true
			}

			if (val === index) {
				return true
			}

			return false
		})

		if (findedIndex !== -1) {
			return findedIndex
		}

		return 0
	}

	function getCurrentIndexByDeltaX(deltaX) {
		const step = deltaX > 0 ? -1 : 1;

		for (
			let i = step;
			currentIndex + i < tabs.length && currentIndex + i >= 0;
			i += step
		) {
			const index = currentIndex + i

			if (
				index >= 0 &&
				index < tabs.length &&
				tabs[index] &&
				!tabs[index].disabled
			) {
				return index;
			}
		}

		return -1;
	}

	function getTabByIndex(index) {
		const tab = tabs.find((item) => {
			return item.index === index
		})

		return tab
	}

	function initStickyContainer() {
		const tabsNode = Taro.createSelectorQuery().select(`#${ref.current.uid}`)

		setStickContainer(tabsNode)
	}
	
	useMount(() => {
		if (sticky) {
			initStickyContainer()
		}
	})
	
	useUpdateEffect(() => {
		setScrollable(getScrollable())
	}, [children])

	return {
		ref,
		currentIndex,
		tabs,
		isLineType,
		scrollable,
		stickyContainer,
		onClickTab,
		onTouchStart,
		onTouchMove,
		onTouchEnd
	}
}

export default useTabs